#include <stdint.h>
#include <stdio.h>

typedef struct {
    uint32_t pid;
    void (*entry)(void);
} PCB;

PCB current_process;

void create_process(void (*entry)(void)) {
    current_process.pid = 1;  // Assign a PID
    current_process.entry = entry;
}

void schedule_processes(void) {
    if (current_process.entry) {
        printf("Running process with PID: %u\n", current_process.pid);
        current_process.entry();
    }
}

// Example process entry function
void my_process() {
    printf("In my process!\n");
}
