#include <stdio.h>

extern void create_process(void (*entry)(void));
extern void schedule_processes(void);
extern void* kmalloc(size_t size);
extern void kfree(void* ptr);

int main(void) {
    printf("Kernel simulation starting...\n");

    void* memory = kmalloc(100);
    if (memory) {
        printf("Memory allocated\n");
    }

    create_process(my_process);
    schedule_processes();

    if (memory) {
        kfree(memory);
        printf("Memory freed\n");
    }

    printf("Kernel simulation finished.\n");
    return 0;
}
