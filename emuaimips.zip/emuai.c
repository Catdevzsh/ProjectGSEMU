#include <stdint.h>

// These would typically be defined externally
uint32_t _bss_start = 0;
uint32_t _bss_end = 0;

void clear_bss(void) {
    uint32_t* bss_start = &_bss_start;
    uint32_t* bss_end = &_bss_end;
    while (bss_start < bss_end) {
        *bss_start++ = 0;
    }
}

int main(void) {
    clear_bss();

    // Placeholder for further initialization and main loop
    while (1) {
        // Main kernel loop
    }

    return 0;
}
